
#1
"""""
kocha="Bog'bon"
mahalla="Sog'bon"
tuman="Bodomzor"
viloyat="Samarqand"

print(f"Bog'bon ko'chasi, Sog'bon mahallasi, Bodomzor tumani, Samarqand viloyati")
"""""
#2

kocha= input("Ko'changizni nomi: ")
mahalla= input("Mahalla nomi: ")
tuman= input("Tuman nomi: ")
viloyat= input("Viloyat nomi: ")
matn = f'Kocha: {kocha}, \nMahalla: {mahalla}, \nTuman: {tuman}, \nViloyat: {viloyat}'
print(matn.title())
print(matn.upper())
print(matn.capitalize())
print(matn.lower())




