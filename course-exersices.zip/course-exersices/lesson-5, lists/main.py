#1

names = ['Max', 'Kevin', 'Alex']

print(names)
print(names[0], ',', 'are okay,my friend')

#2
numbers = [1, -4, 0]

a = numbers[0]+numbers[2]-numbers[1]
print(numbers)
print(a)


#3

friends = []

friends.append('Max')
friends.append('Jhon')
friends.append('Peter')
print(friends)
#4

friends.remove('Peter')
print(friends)

#5
friends.pop()
print(friends)
