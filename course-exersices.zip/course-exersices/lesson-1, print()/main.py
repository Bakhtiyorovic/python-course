


#1

print(f'"BMW", "Mercedes", and "Audi" are german cars')

#2

a = 5
b = 4
c = 5**4
print(f'level 4 of 5 is {c}')

#3

a = 22
b = 4
c = a%b

print(f'22 divided by 4, the remainder would be  {c}')

#4

a = 125

p = 4* a

s = a**2

print(f'surface of square is {s} and perimeter is {p}')


#5

a  = 12

p = 3.14

c = a**2

d = p*c

print(f'diameter of the  circle {d}')


#6

a = 7
b = 6
x = a**2
y = b**2
z = x+y
c = z ** (1/2)

print(f'The hypotenuse of {a}- and {b}-dimensional squares is {c}')

