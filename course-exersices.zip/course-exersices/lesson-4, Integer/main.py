#1

a = int(input("Enter a number: "))
b = a**2
c = a **3
print(f"The square of {a} is {b} and the cube is {c}")


#2

a = int(input("Your age: "))

b = 2024 - a
print(f"You were born in {b}")

#3
a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
c = a+b
d = a-b
e = a*b
f = a/b
print(f'a+b={c}, a-b={d}, a*b={e},a/b={f}')
