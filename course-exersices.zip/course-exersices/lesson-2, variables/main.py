#1

something = "Hello World!"
print(something)

#2

news = 'I do not know'
print(news)
news = 'I do not know anything'
print(news)

#3
"""""
class = 23
print(class)
 """""

