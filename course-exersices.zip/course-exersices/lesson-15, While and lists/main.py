#1

# orders = ['kfc', 'burger', 'pizza']
# products = []
# while True:
#     a = input("Enter your order: ")
#     if a in orders:
#         products.append(a)
#         print(f"Your order is {products}")
#     elif a == "":
#         break




